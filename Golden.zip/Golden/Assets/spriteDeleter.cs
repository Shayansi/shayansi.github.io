using UnityEngine;

public class spriteDeleter : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        DeleteClone();
    }

    private void DeleteClone()
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("player");

        foreach (GameObject player in players)
        {
            if (player.GetComponent<CloneHealth>() != null)
            {
                Destroy(player);
                return;
            }
        }
    }
}
