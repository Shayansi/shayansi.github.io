using UnityEngine;
using TMPro;

public class OldManScript : MonoBehaviour
{
    public RectTransform panel;
    public TMP_Text label;
    [TextArea] public string[] lines;
    public float charsPerSecond = 40f;
    public float betweenLines = 0.5f;
    bool writing = false;
    
    [SerializeField] private ArrowKeyMovement arrowKeyMovement;
    void Start() { }

    public void Play() { if (!writing) {StartCoroutine(Type());} }

    System.Collections.IEnumerator Type()
    {
        writing = true;
        arrowKeyMovement.stop = true;
        
        if (panel) panel.gameObject.SetActive(true);
        foreach (var line in lines)
        {
            label.text = "";
            float t = 0f; int i = 0, L = line.Length;
            while (i < L)
            {
                t += Time.unscaledDeltaTime * charsPerSecond;
                int n = (int)t;
                if (n > i) { i = n > L ? L : n; label.text = line.Substring(0, i); }
                yield return null;
            }

            arrowKeyMovement.stop = false;
            yield return new WaitForSecondsRealtime(betweenLines);
        }
    }

    public void RemoveText()
    {
        if (panel) panel.gameObject.SetActive(false);
        writing = false;
    }
}