using UnityEngine;
using UnityEngine.SceneManagement;

public class CustomSwitch : MonoBehaviour
{
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha4)) // Detects when '4' key is pressed
        {
            SceneManager.LoadScene("CustomLevel");
        }
    }
}
