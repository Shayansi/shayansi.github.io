using UnityEngine;

public class FloorLockMovement : MonoBehaviour
{
    [SerializeField] ArrowKeyMovement arrowKeyMovement;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingFloor = true;
        }
    }
    void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingFloor = true;
        }
    }
    void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingFloor = false;
        }
    }
}
