using UnityEngine;
public class Occupied : MonoBehaviour
{
    [SerializeField] private GameObject slidingBox;
    [SerializeField] private UpLockedDoors lockedDoor;
    private Vector3 rightLocation;
	[SerializeField] private RoomLockOnEntry roomLockOnEntry;

    void Start()
    {
        rightLocation = transform.position;
		roomLockOnEntry.canOpen = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (slidingBox.transform.position == rightLocation)
        {
            OpenSlidingDoor();
        }
    }

    void OpenSlidingDoor()
    {
        if (lockedDoor)
        {
            lockedDoor.ReplaceLockedDoors();
        }
		else if (roomLockOnEntry)
		{
			roomLockOnEntry.canOpen = true;
		}
    }
}
