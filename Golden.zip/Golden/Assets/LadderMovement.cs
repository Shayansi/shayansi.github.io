using UnityEngine;

public class LadderMovement : MonoBehaviour
{
    [SerializeField] ArrowKeyMovement arrowKeyMovement;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingLadder = true;
        }
    }
    void OnTriggerStay(Collider collider)
    {
        if (collider.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingLadder = true;
        }
    }
    void OnTriggerExit(Collider collider)
    {
        if (collider.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingLadder = false;
        }
    }
}
