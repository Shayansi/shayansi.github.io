using UnityEngine;

public class Moveable : MonoBehaviour
{
    public float holdTime = 1f;
    public float timeHeld = 0f;

    [SerializeField] public bool moved = false;
    [SerializeField] private ArrowKeyMovement keyMovement;
	[SerializeField] private RoomLockOnEntry roomLockOnEntry;

    private float blockMoveSpeed = 1f;

    public bool sliding = false;
    public bool allowHorizontal = true;
    public bool allowVertical = true;

    private Vector3 endPos;

    void Update()
    {
		if (roomLockOnEntry && roomLockOnEntry.alive > 0) {return;}
        if (!sliding && timeHeld >= holdTime && !moved)
        {
            var step = CardinalFromInput(keyMovement ? keyMovement.GetInput() : Vector2.zero);
            if (step != Vector2Int.zero)
            {
                moved   = true;
                endPos  = transform.position + new Vector3(step.x, step.y, 0f);
                sliding = true;
            }
            timeHeld = 0f;
        }

        if (sliding)
        {
            transform.position = Vector3.MoveTowards(
                transform.position, endPos, blockMoveSpeed * Time.deltaTime);

            if ((transform.position - endPos).sqrMagnitude < 1e-6f)
                transform.position = endPos;
        }
    }

    void OnCollisionStay(Collision collision)
    {
        if (!collision.gameObject.CompareTag("player")) return;
        if (sliding || moved) return;

        var dir = CardinalFromInput(keyMovement ? keyMovement.GetInput() : Vector2.zero);
        if (dir != Vector2Int.zero) timeHeld += Time.deltaTime;
        else timeHeld = 0f;
    }

    void OnCollisionExit(Collision collision)
    {
        if (!collision.gameObject.CompareTag("player")) return;
        if (!sliding) { timeHeld = 0f; moved = false; }
    }

	Vector2Int CardinalFromInput(Vector2 input)
	{
    	if (input.sqrMagnitude < 0.25f) return Vector2Int.zero;
    	float ax = Mathf.Abs(input.x), ay = Mathf.Abs(input.y);
	    const float dz2 = 0.25f;

    	if (ax > ay)
    	{
        	if (allowHorizontal) return input.x > 0 ? Vector2Int.right : Vector2Int.left;
        	if (allowVertical && ay*ay >= dz2) return input.y > 0 ? Vector2Int.up : Vector2Int.down;
        	return Vector2Int.zero;
    	}
    	else
    	{
        	if (allowVertical) return input.y > 0 ? Vector2Int.up : Vector2Int.down;
        	if (allowHorizontal && ax*ax >= dz2) return input.x > 0 ? Vector2Int.right : Vector2Int.left;
        	return Vector2Int.zero;
    	}
	}

}

