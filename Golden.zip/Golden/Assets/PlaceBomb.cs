using UnityEngine;

public class PlaceBomb : MonoBehaviour
{
    public GameObject bombPrefab;
    public Transform firePoint;
    public float placeCooldown = 0.5f;

    [HideInInspector] public bool bombPlaced = false; // tracked by WeaponManager
    [HideInInspector] public ArrowKeyMovement movement;
    [HideInInspector] public Inventory inventory;

    private float lastPlaceTime = 0f;
    private float percentDistanceFromPlayer = 1.5f;

    void Start()
    {
        movement = GetComponent<ArrowKeyMovement>();
        inventory = GetComponent<Inventory>();
    }

    public void TryToPlaceBomb()
    {
        if (Time.time < lastPlaceTime + placeCooldown)
            return;

        if (inventory.GetBombs() <= 0)
        {
            Debug.Log("No bombs in inventory");
            return;
        }

        inventory.AddBombs(-1);
        PlaceABomb();
        lastPlaceTime = Time.time;
    }

    private void PlaceABomb()
    {
        Vector2 shootDir = GetFacingDirection();
        Vector3 spawnPos = transform.position + (Vector3)shootDir * percentDistanceFromPlayer;

        GameObject bomb = Instantiate(bombPrefab, spawnPos, Quaternion.identity);
        bomb.GetComponent<Bomb>().SetDirection(shootDir);

        Debug.Log("Bomb placed, Remaining bombs: " + inventory.GetBombs());
    }

    private Vector2 GetFacingDirection()
    {
        switch (movement.facingDir)
        {
            case "up": return Vector2.up;
            case "down": return Vector2.down;
            case "left": return Vector2.left;
            case "right": return Vector2.right;
        }
        return Vector2.zero;
    }
}