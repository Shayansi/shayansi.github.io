using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CloneHealth : MonoBehaviour
{
    public static int maxHealth = 1;
    public int currentHealth;
    public Inventory inventory;
    public PlayerHealth playerHealth;

    public float Iduration = 1f; // invincibility duration
    private bool isInvincible = false;

    private Rigidbody rb;
    private SpriteRenderer spriteRenderer;
    private ArrowKeyMovement movement;

    public float knockbackTileDistance = 1f; // distance of one "tile"
    public float knockbackSpeed = 6f;        // how fast to move during knockback
    public float stunDuration = 0.5f;

    private bool isStunned = false;

    private AudioSource audioSource;
    public AudioClip damageSound;

    void Start()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        //inventory = GetComponent<Inventory>();
        movement = GetComponent<ArrowKeyMovement>();
        audioSource = GetComponent<AudioSource>();

        GameObject[] allPlayers = GameObject.FindGameObjectsWithTag("player");

        foreach (GameObject p in allPlayers)
        {
            if (p != this.gameObject) // Skip this object
            {
                playerHealth = p.GetComponent<PlayerHealth>();
                if (playerHealth != null)
                {
                    break; // Found the other player, exit loop
                }
            }
        }
    }

    public void TakeDamage(int amount, Vector3 hitSource)
    {
        if (isInvincible) return;

        if (damageSound != null)
        {
            audioSource.PlayOneShot(damageSound);
        }

        playerHealth.TakeDamage(amount, hitSource);
        if (currentHealth <= 0)
        {
            Die();
            return;
        }

        // Calculate knockback direction
        Vector3 knockbackDir = (transform.position - hitSource).normalized;

        // Start smooth knockback coroutine
        StartCoroutine(SmoothKnockbackCoroutine(knockbackDir));

        // Start invincibility and stun
        StartCoroutine(InvincibilityCoroutine());
        StartCoroutine(StunCoroutine());
    }

    public void Heal(int amount)
    {
        playerHealth.Heal(amount);
    }

    public void MaxHealthIncrease(int amount)
    {
        maxHealth += amount;
        currentHealth += amount;
    }

    public void Die()
    {
        Destroy(gameObject, 2f);
    }

    private System.Collections.IEnumerator InvincibilityCoroutine()
    {
        isInvincible = true;
        float elapsed = 0f;

        while (elapsed < Iduration)
        {
            spriteRenderer.enabled = !spriteRenderer.enabled;
            yield return new WaitForSeconds(0.1f);
            elapsed += 0.1f;
        }

        spriteRenderer.enabled = true;
        isInvincible = false;
    }

    private System.Collections.IEnumerator StunCoroutine()
    {
        isStunned = true;

        if (movement != null)
            movement.enabled = false;

        yield return new WaitForSeconds(stunDuration);

        if (movement != null)
            movement.enabled = true;

        isStunned = false;
    }

    private System.Collections.IEnumerator SmoothKnockbackCoroutine(Vector3 direction)
    {
        if (movement != null)
            movement.enabled = false;

        Vector3 start = transform.position;
        Vector3 target = start + direction * knockbackTileDistance;

        float elapsed = 0f;
        float duration = knockbackTileDistance / knockbackSpeed;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            transform.position = Vector3.Lerp(start, target, t);
            yield return null;
        }

        transform.position = target; // snap to final position

        if (movement != null)
            movement.enabled = true;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Door"))
        {
            //Destroy(gameObject);
        }
    }



}
