using UnityEngine;

public class Boomerang : MonoBehaviour
{
    [Header("Movement")]
    public float speed = 6f;
    public float maxDistance = 5f;
    public float returnSpeedMultiplier = 1.2f;

    [Header("Combat")]
    public int damage = 1;

    [Header("Audio")]
    public AudioClip boomerangLoopClip;
    private AudioSource audioSource;

    private Vector3 startPosition;
    private Vector3 direction;
    private Transform player;
    private Bow bowReference;
    private bool returning = false;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        startPosition = transform.position;

        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = boomerangLoopClip;
        audioSource.loop = true;
        audioSource.playOnAwake = false;
        audioSource.volume = 0.8f;
        audioSource.Play();
    }

    public void Initialize(Vector3 dir, Transform playerTransform, Bow bow)
    {
        direction = dir.normalized;
        player = playerTransform;
        bowReference = bow;
    }

    void Update()
    {
        if (!returning)
        {
            rb.MovePosition(transform.position + direction * speed * Time.deltaTime);

            if (Vector3.Distance(startPosition, transform.position) >= maxDistance)
                returning = true;
        }
        else
        {
            Vector3 toPlayer = (player.position - transform.position).normalized;
            rb.MovePosition(transform.position + toPlayer * speed * returnSpeedMultiplier * Time.deltaTime);

            if (Vector3.Distance(player.position, transform.position) < 0.3f)
            {
                bowReference.boomerangActive = false;
                StopBoomerangSound();
                Destroy(gameObject);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
                enemy.TakeDamage(damage);
        }

        if (other.CompareTag("rupee") || other.CompareTag("heart"))
        {
            other.transform.SetParent(transform);
            other.transform.localPosition = Vector3.zero;
        }

        if (!returning && other.CompareTag("Wall"))
            returning = true;
    }

    private void OnDestroy()
    {
        StopBoomerangSound();
    }

    private void StopBoomerangSound()
    {
        if (audioSource != null && audioSource.isPlaying)
            audioSource.Stop();
    }
}
