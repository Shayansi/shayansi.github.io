using UnityEngine;
using UnityEngine.UI;

public class WeaponManager : MonoBehaviour
{
    public enum WeaponType { Bow, Boomerang, Bomb }
    public WeaponType activeWeapon = WeaponType.Bow;
    
    public Sprite[] altWeaponSprites;
    [SerializeField] private Image sr;

    public Bow bow;
    public PlaceBomb placeBomb;
    public Boomerang boomerangPrefab;
    //public Bomb bombPrefab;           

    private Transform player;
    private int currentWeaponIndex = 0;


    void Start()
    {
        player = transform; // assumes this script is on the player
    }

    void Update()
    {
        // Switch weapons
        if (Input.GetKeyDown(KeyCode.Space))
        {
            activeWeapon = (WeaponType)(((int)activeWeapon + 1) % 3);
            if (currentWeaponIndex > 1)
            {
                currentWeaponIndex = 0;
            }
            else
            {
                currentWeaponIndex++;
            }
            Debug.Log("Switched to: " + activeWeapon);
        }

        // Use active weapon
        if (Input.GetKeyDown(KeyCode.Z))
        {
            switch (activeWeapon)
            {
                case WeaponType.Bow:
                    bow.ShootBow();
                    break;
                case WeaponType.Boomerang:
                    ThrowBoomerang();
                    break;
                case WeaponType.Bomb:
                    placeBomb.TryToPlaceBomb();
                    break;
            }
        }


        //set sprite image for alt weapon
        if (sr != null)
        {
            sr.sprite = altWeaponSprites[currentWeaponIndex % altWeaponSprites.Length];
        }
    }

    private void ThrowBoomerang()
    {
        // Only one boomerang at a time
        if (bow.boomerangActive)
            return;

        string dir = bow.movement.facingDir;
        Vector3 throwDir = Vector3.zero;

        switch (dir)
        {
            case "up": throwDir = Vector3.up; break;
            case "down": throwDir = Vector3.down; break;
            case "left": throwDir = Vector3.left; break;
            case "right": throwDir = Vector3.right; break;
        }

        Vector3 spawnPos = player.position + throwDir * 0.5f;
        Boomerang boomerang = Instantiate(boomerangPrefab, spawnPos, Quaternion.identity);
        boomerang.Initialize(throwDir, player, bow);

        bow.boomerangActive = true;
    }

    private void PlaceBomb()
    {
        //Instantiate(bombPrefab, player.position, Quaternion.identity);
    }
}
