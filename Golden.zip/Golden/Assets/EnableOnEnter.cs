using UnityEngine;
public class EnableOnEnter : MonoBehaviour
{
    public GameObject target;
    [SerializeField] private OldManScript oldMan;
    [SerializeField] private ArrowKeyMovement arrowKeyMovement;
    
    void OnTriggerEnter(Collider c){ if (c.CompareTag("player")) target.SetActive(true);
        if (oldMan)
        {
            oldMan.Play();
        }
    }
}