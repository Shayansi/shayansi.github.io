using UnityEngine;

public class GoriyaBoomerang : MonoBehaviour
{
    public float speed = 5f;         // forward speed
    public float flightTime = 1f;    // time before returning
    private Vector3 direction;
    private float timer;
    private bool returning = false;
    private Vector3 startPosition;   // position where it was thrown from

    public void Launch(Vector2 dir, Vector3 throwPosition)
    {
        direction = new Vector3(dir.x, dir.y, 0).normalized;
        timer = flightTime;
        startPosition = throwPosition;
    }

    private void Update()
    {
        if (!returning)
        {
            // Fly forward
            transform.position += direction * speed * Time.deltaTime;

            timer -= Time.deltaTime;
            if (timer <= 0f)
            {
                returning = true;
            }
        }
        else
        {
            // Return to start position
            Vector3 returnDir = (startPosition - transform.position).normalized;
            transform.position += returnDir * speed * Time.deltaTime;

            if (Vector3.Distance(transform.position, startPosition) < 0.1f)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("player"))
        {
            PlayerHealth player = other.GetComponent<PlayerHealth>();
            if (player != null)
            {
                player.TakeDamage(1, transform.position);
            }
            returning = true; // start returning immediately
        }

        if (other.CompareTag("Wall"))
        {
            returning = true; // return if it hits a wall
        }
    }
}
