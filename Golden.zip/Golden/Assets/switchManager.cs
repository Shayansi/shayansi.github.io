using UnityEngine;

public class switchManager : MonoBehaviour
{

    public bool switch1 = false;
    public bool switch2 = false;

    private SpriteRenderer spriteRend;
    private Color originalColor;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        spriteRend = GetComponent<SpriteRenderer>();

        if (spriteRend != null)
            originalColor = spriteRend.color;
    }


    // Update is called once per frame
    void Update()
    {
        if (switch1 && switch2)
        {
            Destroy(this.gameObject);
        }
        else if (switch1 || switch2)
        {
            if (spriteRend != null)
                spriteRend.color = Color.yellow;
        }
        else
        {
            if (spriteRend != null)
                spriteRend.color = originalColor; 
        }
    }

    public void flipSwitch(int num,bool flip)
    {
        switch (num)
        {
            case 1:
                switch1 = flip;
                break;
            case 2:
                switch2= flip;
                break;
        }
    }
}
