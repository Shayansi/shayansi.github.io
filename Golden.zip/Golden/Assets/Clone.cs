using UnityEngine;
using System;

public class Clone : MonoBehaviour
{
    public Action onCloneDestroyed;

    private void OnDestroy()
    {
        onCloneDestroyed?.Invoke();
    }
}
