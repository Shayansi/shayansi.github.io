using UnityEngine;

public class RayTripwire : MonoBehaviour
{
    [SerializeField] private float rayLength = 20f;
    [SerializeField] private float raySkin = 0.01f;
    [SerializeField] private LayerMask rayMask = ~0;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField] private float moveSpeed = 3f;
    [SerializeField] private float returnSpeed = 3f;

    Collider col;
    bool upPrev, downPrev, leftPrev, rightPrev;
    bool moving = false;
    bool returning = false;
    Vector3 moveDir = Vector3.zero;
    Vector3 startPos;

    void Start()
    {
        col = GetComponent<Collider>();
        startPos = transform.position;
    }

    void Update()
    {
        if (!moving && !returning)
        {
            CheckRay(Vector3.up, ref upPrev);
            CheckRay(Vector3.down, ref downPrev);
            CheckRay(Vector3.left, ref leftPrev);
            CheckRay(Vector3.right, ref rightPrev);
        }

        if (moving)
        {
            Collider hitCol;
            if (HitAhead(out hitCol))
            {
                if (hitCol.transform.root.CompareTag("spike") || hitCol.CompareTag("wall"))
                {
                    moving = false;
                    returning = true;
                }
            }
            Vector3 p = transform.position + moveDir * moveSpeed * Time.deltaTime;
            transform.position = p;
            if (OverlapSpike())
            {
                moving = false;
                returning = true;
            }
        }
        else if (returning)
        {
            Vector3 next = Vector3.MoveTowards(transform.position, startPos, returnSpeed * Time.deltaTime);
            transform.position = next;
            if (Vector3.SqrMagnitude(next - startPos) <= 1e-6f)
            {
                returning = false;
                upPrev = downPrev = leftPrev = rightPrev = false;
                moveDir = Vector3.zero;
            }
        }
    }

    Vector3 FaceOrigin(Vector3 dir)
    {
        Bounds b = col.bounds;
        float half = (Mathf.Abs(dir.x) > 0f) ? b.extents.x : b.extents.y;
        return b.center + dir * (half + raySkin);
    }

    void CheckRay(Vector3 dir, ref bool wasHit)
    {
        Vector3 origin = FaceOrigin(dir);
        RaycastHit hit;
        bool anyHit = Physics.Raycast(origin, dir, out hit, rayLength, rayMask, QueryTriggerInteraction.Ignore);
        bool hitPlayer = anyHit && hit.collider.transform.root.CompareTag("player");
        Debug.DrawRay(origin, dir * rayLength, hitPlayer ? Color.green : (anyHit ? Color.yellow : Color.cyan));
        if (hitPlayer && !wasHit)
        {
            moveDir = dir;
            moving = true;
        }
        wasHit = hitPlayer;
    }

    bool HitAhead(out Collider hitCol)
    {
        Bounds b = col.bounds;
        Vector3 ext = b.extents;
        float castDist = moveSpeed * Time.deltaTime + raySkin;
        RaycastHit hit;
        bool hitSomething = Physics.BoxCast(b.center, ext, moveDir, out hit, Quaternion.identity, castDist, hitMask, QueryTriggerInteraction.Ignore);
        hitCol = hitSomething ? hit.collider : null;
        if (!hitSomething) return false;
        if (hit.collider == col) return false;
        return true;
    }

    bool OverlapSpike()
    {
        Bounds b = col.bounds;
        Collider[] hits = Physics.OverlapBox(b.center, b.extents * 0.98f, Quaternion.identity, hitMask, QueryTriggerInteraction.Ignore);
        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i] != null && hits[i] != col && (hits[i].transform.root.CompareTag("spike") || hits[i].CompareTag("wall"))) return true;
        }
        return false;
    }

    void OnCollisionEnter(Collision c)
    {
        if (c.gameObject.CompareTag("spike"))
        {
            moving = false;
            returning = true;
        }

        if (c.gameObject.CompareTag("player"))
        {
            PlayerHealth playerHealth = c.gameObject.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(1, transform.position);
                Debug.Log("Player hit by Spike");
            }
        }
    }
}
