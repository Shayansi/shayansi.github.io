using UnityEngine;

public class RoomLockOnEntry : MonoBehaviour
{
    [SerializeField] Transform enemiesParent;
    [SerializeField] DoorController rightDoor;
    public bool canOpen = false;

    public int alive;

    void Awake()
    {
        alive = CountAlive();
        Debug.Log(alive);
        
        if (alive <= 0)
        {
            rightDoor.Unlock();
        }
    }

    void Update()
    {
        if (alive <= 0 && canOpen)
        {
            rightDoor.Unlock();
        }
    }

    int CountAlive()
    {
        return enemiesParent ? enemiesParent.GetComponentsInChildren<Enemy>(true).Length : 0;
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("player"))
        {
            return;
        }
        
        if (alive > 0 || !canOpen) rightDoor.Lock();
    }
    public void OnEnemyDied()
    {
        alive--;
        if (alive <= 0 && canOpen) rightDoor.Unlock();
    }
}