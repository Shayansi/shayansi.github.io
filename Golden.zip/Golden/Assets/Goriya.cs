using UnityEngine;

public class Goriya : Enemy
{
    [Header("Movement")]
    public float moveSpeed = 2f;
    public float changeDirectionInterval = 2f;
    private Vector2 moveDirection;
    private float changeTimer;

    [Header("Boomerang")]
    public GameObject boomerangPrefab;
    public float throwInterval = 3f;
    private float throwTimer;
    private GoriyaBoomerang activeBoomerang;

    [Header("Sprites")]
    public Sprite upSprite;
    public Sprite downSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;

    private Rigidbody rb;
    private SpriteRenderer sr;

    protected override void Start()
    {
        base.Start();
        rb = GetComponent<Rigidbody>();
        sr = GetComponentInChildren<SpriteRenderer>();

        changeTimer = changeDirectionInterval;
        throwTimer = throwInterval;

        PickRandomDirection();
        UpdateSprite();
    }

    private void Update()
    {
        if (!isVisible && !isStunned) return;

        HandleStun();

        if (!isStunned && activeBoomerang == null)
        {
            Move();
            HandleDirectionChange();
            HandleBoomerangThrow();
        }

        if (activeBoomerang != null && !activeBoomerang.gameObject.activeInHierarchy)
        {
            activeBoomerang = null;
        }
    }

    private void Move()
    {
        Vector3 movement3D = new Vector3(moveDirection.x, 0, moveDirection.y);
        rb.MovePosition(rb.position + movement3D * moveSpeed * Time.deltaTime);
    }

    private void HandleDirectionChange()
    {
        changeTimer -= Time.deltaTime;
        if (changeTimer <= 0f)
        {
            PickRandomDirection();
            changeTimer = changeDirectionInterval;
            UpdateSprite();
        }
    }

    private void PickRandomDirection()
    {
        int dir = Random.Range(0, 4);
        switch (dir)
        {
            case 0: moveDirection = Vector2.up; break;
            case 1: moveDirection = Vector2.down; break;
            case 2: moveDirection = Vector2.left; break;
            case 3: moveDirection = Vector2.right; break;
        }
    }

    private void UpdateSprite()
    {
        if (sr == null) return;

        if (moveDirection == Vector2.up) sr.sprite = upSprite;
        else if (moveDirection == Vector2.down) sr.sprite = downSprite;
        else if (moveDirection == Vector2.left) sr.sprite = leftSprite;
        else if (moveDirection == Vector2.right) sr.sprite = rightSprite;
    }

    private void HandleBoomerangThrow()
    {
        throwTimer -= Time.deltaTime;
        if (throwTimer <= 0f && boomerangPrefab != null)
        {
            ThrowBoomerang();
            throwTimer = throwInterval;
        }
    }

    private void ThrowBoomerang()
    {
        if (boomerangPrefab != null)
        {
            GameObject boomerangObj = Instantiate(boomerangPrefab, transform.position, Quaternion.identity);

            GoriyaBoomerang boomerangScript = boomerangObj.GetComponent<GoriyaBoomerang>();
            if (boomerangScript != null)
            {
                boomerangScript.Launch(moveDirection, transform.position);
                activeBoomerang = boomerangScript;
            }
        }
    }
}
