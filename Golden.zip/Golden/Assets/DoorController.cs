using UnityEngine;

public class DoorController : MonoBehaviour
{
    [SerializeField] GameObject blocker;

    public void Lock()
	{ 
		if (blocker) 
		{
			blocker.SetActive(true);
		}
	}
    public void Unlock() 
	{
		if (blocker) 
		{
			blocker.SetActive(false);
		}
	}
}
