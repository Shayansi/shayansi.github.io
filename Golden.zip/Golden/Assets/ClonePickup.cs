using UnityEngine;

public class ClonePickup : MonoBehaviour
{

    public AudioClip pickupSound;
    public float volume = 1f;
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("player"))
        {
            Inventory inventory = other.GetComponent<Inventory>();
            if (inventory != null)
            {
                inventory.hasClone = true;
                Debug.Log("Clone ability unlocked!");
            }

            if (pickupSound != null)
            {
                AudioSource.PlayClipAtPoint(pickupSound, transform.position, volume);
            }

            Destroy(gameObject);
        }
    }
}
