using UnityEngine;
using UnityEngine.Audio;

[RequireComponent(typeof(Rigidbody))]
public class Aquamentus : Enemy
{
    [Header("Movement Settings")]
    public float moveSpeed = 2f;             // Movement speed in units per second
    public float tileSize = 1f;              // Size of one tile
    public float followDistance = 5f;        // Distance threshold in tiles

    [Header("Fireball Settings")]
    public GameObject fireballPrefab;        // Assign your fireball prefab here
    public float fireInterval = 2f;          // Time between each volley
    public float fireSpeed = 5f;             // Speed of fireballs
    public float spreadAngle = 15f;          // Angle between fireballs in degrees

    private Transform player;
    private float fireTimer = 0f;
    private Renderer rend;

    public AudioClip aquaSound;
    private AudioSource audioSource;
    private bool playedSound = false;

    protected override void Start()
    {
        base.Start();

        rend = GetComponentInChildren<Renderer>();

        audioSource = GetComponentInChildren<AudioSource>();

        GameObject playerObj = GameObject.FindGameObjectWithTag("player");
        if (playerObj != null)
            player = playerObj.transform;
    }

    private void FixedUpdate()
    {
        if (player == null) return;

        if (rend != null && !rend.isVisible) {
        return;
        } 
        else{
            if (aquaSound != null && !playedSound)
            {
                audioSource.PlayOneShot(aquaSound);
                playedSound = true;
            }
        }


        HandleMovement();
        HandleFiring();
    }

    private void HandleMovement()
    {
        float horizontalDistance = player.position.x - transform.position.x;

        Vector3 moveDir = Vector3.zero;

        if (Mathf.Abs(horizontalDistance) > tileSize * followDistance)
        {
            moveDir = Vector3.left;
        }
        else
        {
            moveDir = Vector3.right;
        }

        Vector3 newPos = Vector3.MoveTowards(transform.position, transform.position + moveDir, moveSpeed * Time.fixedDeltaTime);
        rb.MovePosition(newPos);
    }

    private void HandleFiring()
    {
        fireTimer += Time.fixedDeltaTime;

        if (fireTimer >= fireInterval)
        {
            fireTimer = 0f;
            ShootFireballs();
        }
    }

    private void ShootFireballs()
    {
        if (player == null || fireballPrefab == null) return;

        Vector3 directionToPlayer = (player.position - transform.position).normalized;

        // Rotate direction for left/right fireballs in spread
        Vector3 leftDir = Quaternion.Euler(0, 0, spreadAngle) * directionToPlayer;
        Vector3 rightDir = Quaternion.Euler(0, 0, -spreadAngle) * directionToPlayer;

        SpawnFireball(directionToPlayer);
        SpawnFireball(leftDir);
        SpawnFireball(rightDir);
    }

    private void SpawnFireball(Vector3 direction)
    {
        Debug.Log("Spawned Fireball");
        GameObject fireball = Instantiate(fireballPrefab, transform.position, Quaternion.identity);
        Rigidbody fireRb = fireball.GetComponent<Rigidbody>();

        if (fireRb != null)
            fireRb.linearVelocity = direction * fireSpeed;
    }

    private void OnDrawGizmosSelected()
    {
        if (player != null)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawLine(transform.position, player.position);
        }
    }
}
