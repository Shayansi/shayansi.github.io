using UnityEngine;

public class KeySpawner : MonoBehaviour
{
    public GameObject[] objectsToWatch;
    public GameObject keyPrefab;
    public Transform spawnPoint;

    private bool hasSpawned = false;


    void Start()
    {
        if (spawnPoint == null)
            spawnPoint = transform;
    }
    void Update()
    {
        if (!hasSpawned && AllObjectsDestroyed())
        {
            SpawnKey();
        }
    }

    private bool AllObjectsDestroyed()
    {
        foreach (GameObject obj in objectsToWatch)
        {
            if (obj != null)
                return false;
        }
        return true;
    }

    private void SpawnKey()
    {
        if (keyPrefab != null)
        {
            Instantiate(keyPrefab, spawnPoint.position, spawnPoint.rotation);
            hasSpawned = true;
        }
    }
}
