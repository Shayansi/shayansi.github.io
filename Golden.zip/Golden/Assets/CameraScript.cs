using UnityEngine;

[ExecuteAlways]
[RequireComponent(typeof(Camera))]
public class CameraScript : MonoBehaviour
{
    public int targetWidth  = 1024;

    public int targetHeight = 960;
    
    public bool setOrthoFromPPU = true;
    public int pixelsPerUnit = 16;
    public float extraUnitsTopAndBottom = 0f;
 
    Camera cam;
    Camera bgCam;
    int lastW, lastH;

    void OnEnable()
    {
        cam = GetComponent<Camera>();
        EnsureBackgroundCamera();
        Apply();
    }

    void OnDisable()
    {
        if (cam) cam.rect = new Rect(0, 0, 1, 1);
        if (bgCam) bgCam.enabled = false;
    }

    void Update()
    {
        if (Screen.width != lastW || Screen.height != lastH)
        {
            Apply();
        }
    }

    void EnsureBackgroundCamera()
    {
        if (bgCam)
        {
            bgCam.enabled = true;
            return;
        }

        var go = new GameObject("Letterbox Background Camera");
        go.transform.SetParent(transform, false);

        bgCam = go.AddComponent<Camera>();
        bgCam.depth = cam.depth - 100;
        bgCam.clearFlags = CameraClearFlags.SolidColor;
        bgCam.backgroundColor = Color.black;
        bgCam.cullingMask = 0;
        bgCam.orthographic = true;
        bgCam.rect = new Rect(0, 0, 1, 1);
    }

    public void Apply()
    {
        lastW = Screen.width; lastH = Screen.height;

        if (setOrthoFromPPU && cam.orthographic && pixelsPerUnit > 0)
        {
            cam.orthographicSize = (targetHeight / (2f * pixelsPerUnit)) + extraUnitsTopAndBottom;
        }

        float targetAspect = (float)targetWidth / targetHeight;
        float windowAspect = (float)Screen.width / Screen.height;

        if (windowAspect > targetAspect)
        {
            float widthNorm = targetAspect / windowAspect;
            cam.rect = new Rect((1f - widthNorm) * 0.5f, 0f, widthNorm, 1f);
        }
        else
        {
            float heightNorm = windowAspect / targetAspect;
            cam.rect = new Rect(0f, (1f - heightNorm) * 0.5f, 1f, heightNorm);
        }
    }
}
