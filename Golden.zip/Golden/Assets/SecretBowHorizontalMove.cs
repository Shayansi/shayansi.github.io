using UnityEngine;

public class SecretBowHorizontalMove : MonoBehaviour
{
    [SerializeField] ArrowKeyMovement arrowKeyMovement;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingFloor = true;
        }
    }
    void OnTriggerStay(Collider collider)
    {
        if (collider.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingFloor = true;
        }
    }
    void OnTriggerExit(Collider collider)
    {
        if (collider.gameObject.CompareTag("player"))
        {
            arrowKeyMovement.touchingFloor = false;
        }
    }
}
