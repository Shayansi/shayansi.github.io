using UnityEngine;

public class Inventory : MonoBehaviour
{
    private int rupeeCount = 0;
    private int rupeeCountMax = 99;
    private int keyCount = 0;
    private int keyCountMax = 3;
    private int bombCount = 0;
    private int bombCountMax = 3;
    public bool godMode = false;

    public bool hasClone = false;
    [SerializeField] private swordhitbox swordhitbox;

    void Start()
    {
        godMode = false;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            godMode = !godMode;
            Physics2D.IgnoreLayerCollision(LayerMask.NameToLayer("Player"), LayerMask.NameToLayer("Enemies"), true);
            swordhitbox.GodModeCallOn();
        }
        else
        {
            Physics2D.IgnoreLayerCollision(LayerMask.NameToLayer("Player"), LayerMask.NameToLayer("Enemies"), false);
            swordhitbox.GodModeCallOff();
        }
    }

    public void AddRupees(int numRupees)
    {
        rupeeCount += numRupees;
    }
    
    public void AddKeys(int numKeys)
    {
        if ((keyCount + numKeys >= 0) && (keyCount + numKeys <= keyCountMax))
        keyCount += numKeys;
    }
    
    public void AddBombs(int numBombs)
    {
        if ((bombCount + numBombs >= 0) && (bombCount + numBombs <= bombCountMax))
            bombCount += numBombs;
    }

    public int GetRupees()
    {
        if (godMode)
        {
            return rupeeCountMax;
        }
        else
        {
            if (rupeeCount < 0)
            {
                rupeeCount = 0;
            }
            return rupeeCount;
        }
    }
    
    public int GetKeys()
    {
        if (godMode)
        {
            return keyCountMax;
        }
        else
        {
            return keyCount;
        }
    }
    
    public int GetBombs()
    {
        if (godMode)
        {
            return bombCountMax;
        }
        else
        {
            return bombCount;
        }
    }
}
