using UnityEngine;

public class UpLockedDoors : MonoBehaviour
{
    public GameObject prefab;
    public UpLockedDoors partnerObject;
    public Inventory inventory;
    [SerializeField] private string doorType;

    public string type;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("player") && inventory.GetKeys() >= 1 && (doorType != "sliding"))
        {
            ReplaceLockedDoors();
            if (type == "Up")
            {
                partnerObject.ReplaceLockedDoors();
            }
            inventory.AddKeys(-1);
        }
    }

    public void ReplaceLockedDoors()
    {
        Instantiate(prefab, transform.position, transform.rotation);
        Destroy(gameObject);
    }
}
