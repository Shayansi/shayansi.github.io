using UnityEngine;
using TMPro;
public class KeyDisplayer : MonoBehaviour
{
    public Inventory inventory;
    private TextMeshProUGUI textComponentKeys;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        textComponentKeys = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        if (inventory != null && textComponentKeys != null)
        {
            textComponentKeys.text = "Key Count: " + inventory.GetKeys().ToString();
        }
    }
}
