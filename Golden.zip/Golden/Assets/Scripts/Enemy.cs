using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Health")]
    public int maxHealth = 3;
    private int currentHealth;

    [Header("Stun Settings")]
    public float stunDuration = 1f;
    protected bool isStunned = false;
    private float stunTimer = 0f;

    [Header("Flashing Settings")]
    public float flashInterval = 0.15f;
    protected SpriteRenderer spriteRenderer;
    private float flashTimer = 0f;
    private bool isSpriteVisible = true;

    [Header("References")]
    public MonoBehaviour movementScript;
    protected Rigidbody rb;

    public static GameObject[] dropItems;
    [SerializeField] GameObject dropSpecific;
    public bool dropItem = false;
    public float dropChance = 0.2f;
    [SerializeField] AudioClip enemyHitSound;
    [SerializeField] AudioClip enemyDeathSound;
    [SerializeField] RoomLockOnEntry roomLockOnEntry;

    protected bool isVisible = false; 

    protected virtual void Start()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody>();
        spriteRenderer = GetComponent<SpriteRenderer>();

        if (movementScript == null)
        {
            Debug.LogWarning($"{gameObject.name} has no movement script assigned!");
        }
        if (spriteRenderer == null)
        {
            Debug.LogError($"{gameObject.name} has no SpriteRenderer component!");
        }
    }

    private void Update()
    {
        // If not visible, completely skip updates like AI
        if (!isVisible && !isStunned) return;

        HandleStun();
    }

    public void TakeDamage(int damage, bool applyStun = true)
    {
        currentHealth -= damage;
        Debug.Log($"{gameObject.name} took damage. HP: {currentHealth}");

        if (applyStun)
        {
            Stun(stunDuration);
        }

        if (currentHealth <= 0)
        {
            Die();
            if (enemyDeathSound != null)
                AudioSource.PlayClipAtPoint(enemyDeathSound, Camera.main.transform.position);
        }
        else
        {
            if (enemyHitSound != null)
                AudioSource.PlayClipAtPoint(enemyHitSound, Camera.main.transform.position);
        }
    }

    protected void Stun(float duration)
    {
        if (movementScript != null)
        {
            movementScript.enabled = false; // Disable the movement behavior
        }

        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero; // Stop any sliding motion
        }

        isStunned = true;
        stunTimer = duration;

        // Reset flashing
        flashTimer = 0f;
        isSpriteVisible = true;
        if (spriteRenderer != null)
            spriteRenderer.enabled = true;

        Debug.Log($"{gameObject.name} stunned for {duration} seconds!");
    }

    protected void HandleStun()
    {
        if (!isStunned) return;

        stunTimer -= Time.deltaTime;

        // --- Handle Flashing ---
        flashTimer -= Time.deltaTime;
        if (flashTimer <= 0f)
        {
            flashTimer = flashInterval;
            isSpriteVisible = !isSpriteVisible; // toggle visibility
            if (spriteRenderer != null)
                spriteRenderer.enabled = isSpriteVisible;
        }

        // --- End Stun ---
        if (stunTimer <= 0f)
        {
            isStunned = false;

            // Ensure sprite is visible at the end
            if (spriteRenderer != null)
                spriteRenderer.enabled = true;

            if (movementScript != null && isVisible) // Only re-enable if visible
                movementScript.enabled = true;

            Debug.Log($"{gameObject.name} recovered from stun.");
        }
    }

    private void Die()
    {
        Debug.Log($"{gameObject.name} died.");

        if (roomLockOnEntry)
        {
            roomLockOnEntry.OnEnemyDied();
        }

        // Handle item drops
        if (dropItem && dropSpecific)
        {
            Instantiate(dropSpecific, transform.position, Quaternion.identity);
        }
        else if (dropItems != null && dropItems.Length > 0 && Random.value <= dropChance)
        {
            int index = Random.Range(0, dropItems.Length);
            Instantiate(dropItems[index], transform.position, Quaternion.identity);
        }

        Destroy(gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("weapon"))
        {
            TakeDamage(1, true); // Damage and stun when hit by weapon
        }
        else if (collision.gameObject.CompareTag("player"))
        {
            Debug.Log("Enemy collided with object tagged: " + collision.gameObject.tag);
            PlayerHealth playerHealth = collision.gameObject.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(1, transform.position);
                Debug.Log("Player hit by Enemy");
            }
            else
            {
                CloneHealth cloneHealth = collision.gameObject.GetComponent<CloneHealth>();
                cloneHealth.TakeDamage(1, transform.position);
                Debug.Log("Clone hit by Enemy");
            }
        }
    }


    private void OnBecameVisible()
    {
        isVisible = true;

        // Only re-enable movement if not stunned
        if (movementScript != null && !isStunned)
            movementScript.enabled = true;

        Debug.Log($"{gameObject.name} is now visible. Movement resumed.");
    }

    private void OnBecameInvisible()
    {
        isVisible = false;

        // Disable movement when off-screen
        if (movementScript != null)
            movementScript.enabled = false;

        if (rb != null)
            rb.linearVelocity = Vector3.zero;

        Debug.Log($"{gameObject.name} is now invisible. Movement frozen.");
    }
}
