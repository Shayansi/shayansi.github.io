using UnityEngine;

public class swordbeam : MonoBehaviour
{

    public float speed = 5f;
    public int damage = 1;
    public Vector2 direction;

    [Header("Animation")]
    public Sprite beamUp1, beamUp2;
    public Sprite beamDown1, beamDown2;
    public Sprite beamLeft1, beamLeft2;
    public Sprite beamRight1, beamRight2;
    public float frameSwitchTime = 0.1f;

    private SpriteRenderer spriteRenderer;
    private float timer;
    private Sprite currentFrame1;
    private Sprite currentFrame2;
    [SerializeField] private GameObject explosionPrefab;
    [SerializeField] private float explosionSeconds = 1f;

    public System.Action onBeamDestroyed;
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        currentFrame1 = beamUp1;
        currentFrame2 = beamUp2;
        spriteRenderer.sprite = currentFrame1;
    }
    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.up * speed * Time.deltaTime);
        AnimateBeam();
    }

    private void AnimateBeam()
    {
        timer -= Time.deltaTime;

        if (timer <= 0f)
        {
            // Swap between the two sprites
            if (spriteRenderer.sprite == currentFrame1)
            {
                spriteRenderer.sprite = currentFrame2;
            }
            else
            {
                spriteRenderer.sprite = currentFrame1;
            }

            // Reset timer
            timer = frameSwitchTime;
        }
    }

    private void SelectSpriteSet(Vector2 dir)
    {
        // Check whether the beam is moving horizontally or vertically

        if (Mathf.Abs(dir.x) > Mathf.Abs(dir.y))
        {
            // Horizontal
            if (dir.x > 0)
            {
                // Moving Right
                currentFrame1 = beamRight1;
                currentFrame2 = beamRight2;
            }
            else
            {
                // Moving Left
                currentFrame1 = beamLeft1;
                currentFrame2 = beamLeft2;
            }
        }
        else
        {
            // Vertical
            if (dir.y > 0)
            {
                // Moving Up
                currentFrame1 = beamUp1;
                currentFrame2 = beamUp2;
            }
            else
            {
                // Moving Down
                currentFrame1 = beamDown1;
                currentFrame2 = beamDown2;
            }
        }
    }

    private void OnDestroy()
    {
        // Notify Sword.cs that the beam has been destroyed
        onBeamDestroyed?.Invoke();
    }


    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Sword Beam hit: " + other.gameObject.name + " | Tag: " + other.tag);
        // Damage enemies
        if (other.CompareTag("Enemy"))
        {
            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
            {

                enemy.TakeDamage(damage);
            }

            Explode();
            Destroy(gameObject);
        }

        // Destroy when hitting wall or enemy
        if (other.CompareTag("Wall") || other.CompareTag("Enemy"))
        {
            Explode();
            Destroy(gameObject);
        }
    }

    private void Explode()
    {
        GameObject fx = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        Destroy(fx, explosionSeconds);
    }

}