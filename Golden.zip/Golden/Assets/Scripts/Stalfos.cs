using UnityEngine;

public class Stalfos : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2f;
    public float wanderTime = 2f;

    [Header("Health")]
    public int maxHealth = 3;

    private int currentHealth;
    private Rigidbody rb;
    private Vector2 moveDirection;
    private float wanderTimer;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        currentHealth = maxHealth;
        wanderTimer = 0f; // Force picking a direction immediately
    }
    // Update is called once per frame
    void Update()
    {
        // Count down the wander timer
        wanderTimer -= Time.deltaTime;

        // If timer runs out, pick a new random direction
        if (wanderTimer <= 0f)
        {
            PickRandomDirection();
            wanderTimer = wanderTime;
        }
    }

    void FixedUpdate()
    {
        Vector3 movement3D = new Vector3(moveDirection.x, moveDirection.y, 0);

        // Move the Stalfos
        rb.MovePosition(rb.position + movement3D * moveSpeed * Time.fixedDeltaTime);

    }

    private void PickRandomDirection()
    {
        int dir = Random.Range(0, 4); // 0-3
        switch (dir)
        {
            case 0: moveDirection = Vector2.up; break;
            case 1: moveDirection = Vector2.down; break;
            case 2: moveDirection = Vector2.left; break;
            case 3: moveDirection = Vector2.right; break;
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        Debug.Log("Stalfos took damage. HP: " + currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        Debug.Log("Stalfos died");
        Destroy(gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("Stalfos hit: " + collision.gameObject.name + " | Tag: " + collision.gameObject.tag);
        if (collision.gameObject.CompareTag("wall"))
        {
            PickRandomDirection();
        }

        // move to weapon
        if (collision.gameObject.CompareTag("weapon"))
        {
            TakeDamage(1);
        }

        if (collision.gameObject.CompareTag("player"))
        {
            PlayerHealth playerHealth = collision.gameObject.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(1, transform.position);
                Debug.Log("Player hit by Stalfos");
            }

            // TODO: add player stun
        }
    }

}