using UnityEngine;
using System.Collections;

public class ThroughDoor : MonoBehaviour
{
    public bool collided = false;

    private CameraSlider camSlider;

    public string doorDirection;

    private float xDist = 0f;
    private float yDist = 0f;

    private float cameraSlideX = 16;
    private float cameraSlideY = 11;

	public bool rightWay = false; 
	public ArrowKeyMovement arrowKeyMovement;
    public Rigidbody rb;

	public Vector3 positionTranslate;
	[SerializeField] ResetBlock resetBlock;

	//MANUALLY MOVE THE CHARACTER AFTER THEY WALK THROUGH THE DOOR TO MAKE SURE THAT THEY CAN TRIGGER THE OTHER
	//CAMERA MOVE DIRECTION ONLY AFTER THEY'VE WALKED INTO THE OTHER ROOM

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        camSlider = Camera.main.GetComponent<CameraSlider>();
		arrowKeyMovement = GameObject.FindWithTag("player").GetComponent<ArrowKeyMovement>();
        rb = GameObject.FindWithTag("player").GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
		
        DecideCameraMovePositions();
        GameObject objectCollidedWith = other.gameObject;
        collided = true;
        if (objectCollidedWith.CompareTag("player") && rightWay)
        {
            arrowKeyMovement.rb.position = transform.position + positionTranslate;
            DestroyClone();
            if (objectCollidedWith.GetComponent<CloneHealth>() != null)
            {
                Destroy(objectCollidedWith);
            }
            camSlider.CallStart(collided, xDist, yDist, positionTranslate);
			resetBlock.BlockMove();
        }
        collided = false;
    }
    public void DestroyClone()
    {
        GameObject[] players = GameObject.FindGameObjectsWithTag("player");

        foreach (GameObject player in players)
        {
            if (player.GetComponent<CloneHealth>() != null)
            {
                Destroy(player);
                return;
            }
        }
    }

    void DecideCameraMovePositions()
    {
		Vector2 direction = arrowKeyMovement.GetInput();
        if ((doorDirection == "Left") && (direction.x < 0))
        {
            xDist = -1 * cameraSlideX;
            yDist = 0f;
			rightWay = true;
			positionTranslate = new Vector3(-1.5f, 0f, 0f);
        }
        else if ((doorDirection == "Right") && (direction.x > 0))
        {
            xDist = cameraSlideX;
            yDist = 0f;
			rightWay = true;
			positionTranslate = new Vector3(1.5f, 0f, 0f);
        }
        else if (doorDirection == "Up" && direction.y > 0)
        {
            xDist = 0f;
            yDist = cameraSlideY;
			rightWay = true;
			positionTranslate = new Vector3(0f, 1.5f, 0f);
        }
        else if (doorDirection == "Down" && direction.y < 0)
        {
            xDist = 0f;
            yDist = -1 * cameraSlideY;
			rightWay = true;
			positionTranslate = new Vector3(0f, -1.5f, 0f);
        }
        else
        {
            xDist = 0f;
            yDist = 0f;
			rightWay = false;
			positionTranslate = new Vector3(0,0,0);
        }
    }
}
