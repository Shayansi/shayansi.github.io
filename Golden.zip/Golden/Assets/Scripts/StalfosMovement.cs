using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class StalfosMovement : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2f;
    public float wanderTime = 2f;

    private Rigidbody rb;
    private Vector2 moveDirection;
    private float wanderTimer;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        wanderTimer = 0f;
    }

    private void Update()
    {
        wanderTimer -= Time.deltaTime;

        if (wanderTimer <= 0f)
        {
            PickRandomDirection();
            wanderTimer = wanderTime;
        }
    }

    private void FixedUpdate()
    {
        Vector3 movement3D = new Vector3(moveDirection.x, moveDirection.y, 0);
        rb.MovePosition(rb.position + movement3D * moveSpeed * Time.fixedDeltaTime);
    }

    public void PickRandomDirection()
    {
        int dir = Random.Range(0, 4); // 0-3
        switch (dir)
        {
            case 0: moveDirection = Vector2.up; break;
            case 1: moveDirection = Vector2.down; break;
            case 2: moveDirection = Vector2.left; break;
            case 3: moveDirection = Vector2.right; break;
        }
    }
}
