using TMPro;
using UnityEngine;

public class HeartDisplayer : MonoBehaviour
{
    public PlayerHealth playerHealth;
    private TextMeshProUGUI textComponentKeys;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        textComponentKeys = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        if (playerHealth != null && textComponentKeys != null)
        {
            textComponentKeys.text = "Heart Count: " + playerHealth.currentHealth;
        }
    }
}
