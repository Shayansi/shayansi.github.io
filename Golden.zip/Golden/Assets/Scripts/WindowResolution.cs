using UnityEngine;

public class WindowResolution : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        #if !UNITY_EDITOR
        Screen.SetResolution(1024, 960, FullScreenMode.Windowed);
        #endif
    }
    
}
