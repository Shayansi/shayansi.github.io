using UnityEngine;
using System.Collections;
public class CameraSlider : MonoBehaviour
{
    public float cameraSlideSpeed = 2f;
    public bool moving = false;
    public bool collided = false;
    public ArrowKeyMovement arrowKeyMovement;
    void Start()
    {
        arrowKeyMovement = GameObject.FindWithTag("player").GetComponent<ArrowKeyMovement>();
    }
    public void CallStart(bool  collided, float xDiff, float yDiff, Vector3 positionTranslate)
    {
        StartCoroutine(StartTransition(collided, xDiff, yDiff, positionTranslate));
    }

    public IEnumerator StartTransition(bool collided, float xDiff, float yDiff, Vector3 positionTranslate)
    {
        while (collided)
        {
            if (!moving)
            {
                moving = true;
                arrowKeyMovement.stop = true;
                yield return new WaitForSeconds(0.2f);
                Vector3 startPos = transform.position;
                Vector3 finalPos = new Vector3(startPos.x + xDiff, startPos.y + yDiff, startPos.z);

                yield return StartCoroutine(CoroutineUtilities.MoveObjectOverTime(transform, startPos, finalPos, cameraSlideSpeed));

                arrowKeyMovement.rb.position = arrowKeyMovement.rb.position + positionTranslate;
                moving = false;
            }
            collided = false;
            arrowKeyMovement.stop = false;
            yield return null;
        }
    }
}
