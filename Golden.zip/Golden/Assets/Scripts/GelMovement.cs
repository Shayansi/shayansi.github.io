using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class GelMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    public float tileSize = 1f;
    public float moveSpeed = 3f;
    public float minPause = 0.3f;
    public float maxPause = 0.8f;

    private Rigidbody rb;
    private Vector3 currentDirection;
    private bool isMoving = false;

    private Vector3[] directions = new Vector3[]
    {
        Vector3.up,
        Vector3.down,
        Vector3.left,
        Vector3.right
    };

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionZ;
        StartCoroutine(MoveRoutine());
    }

    private System.Collections.IEnumerator MoveRoutine()
    {
        while (true)
        {
            // Pick a random direction
            currentDirection = directions[Random.Range(0, directions.Length)];

            // Move 1 or 2 tiles
            int tilesToMove = Random.Range(1, 3);
            Vector3 targetPosition = transform.position + currentDirection * tileSize * tilesToMove;

            isMoving = true;

            // Smoothly move toward the target
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f && isMoving)
            {
                Vector3 newPos = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                rb.MovePosition(newPos);
                yield return null;
            }

            // Snap to exact tile position
            transform.position = new Vector3(
                Mathf.Round(transform.position.x),
                Mathf.Round(transform.position.y),
                transform.position.z
            );

            isMoving = false;

            // Pause before the next move
            float pause = Random.Range(minPause, maxPause);
            yield return new WaitForSeconds(pause);
        }
    }

    // Detect when the Gel hits a wall
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            // Stop current movement and pick a new direction
            isMoving = false;
        }
    }
}
