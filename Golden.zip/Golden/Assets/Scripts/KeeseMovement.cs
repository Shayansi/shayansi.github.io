using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class KeeseMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 1.5f;
    public float directionChangeInterval = 1f;
    public float pauseChance = 0.2f; 

    private Rigidbody rb;
    private Vector3 moveDirection;
    private float directionChangeTimer;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionZ;

        PickRandomDirection();
        directionChangeTimer = directionChangeInterval;
    }

    void Update()
    {
        directionChangeTimer -= Time.deltaTime;

        if (directionChangeTimer <= 0f)
        {
            if (Random.value < pauseChance)
            {
                moveDirection = Vector3.zero;
            }
            else
            {
                PickRandomDirection();
            }

            directionChangeTimer = directionChangeInterval;
        }
    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + moveDirection * moveSpeed * Time.fixedDeltaTime);
    }

    private void PickRandomDirection()
    {
        float angle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
        moveDirection = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0f).normalized;
    }
}
