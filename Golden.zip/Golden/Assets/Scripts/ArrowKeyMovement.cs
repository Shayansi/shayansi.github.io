using UnityEngine;

public class ArrowKeyMovement : MonoBehaviour
{
    public Rigidbody rb;
    public float playerMoveSpeed;

    public Sprite[] downFrames;
    public Sprite[] upFrames;
    public Sprite[] rightFrames;
    public Sprite[] leftFrames;
    public string facingDir;
    public bool isAttacking;
     
    public float frameTime = 0.15f;
    public bool walking = false;
    public bool lockHorizontalMove = false;
    public bool lockVerticalMove = false;
    public bool touchingFloor = false;
    public bool touchingLadder = false;
    public bool inBowRoom = false;


    SpriteRenderer sr;
    private Sword sword;
    float frameTimer;
    int frameIndex;
    Vector2 lastMoveDirection = Vector2.down;

	public bool stop = false;
    
    //Grid Movement Additions
    public float tileSize = 1f;
    public float snapEps  = 0.01f;
    private float halfStep = 0.5f;
    float RoundToMultiple(float v, float step) => Mathf.Round(v / step) * step;
    
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        sr = GetComponent<SpriteRenderer>();

        Vector2 p = rb.position;
        
        p.x = RoundToMultiple(p.x, halfStep);
        p.y = RoundToMultiple(p.y, halfStep);
        rb.position = p;
    }

    // Update is called once per frame
    void Update()
    {
        BowRoomLogicHandle();
        Vector2 aimRaw = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        Vector2 aim = Vector2.zero;
        if (Mathf.Abs(aimRaw.x) > Mathf.Abs(aimRaw.y)) aim = new Vector2(Mathf.Sign(aimRaw.x), 0f);
        else if (Mathf.Abs(aimRaw.y) > 0f) aim = new Vector2(0f, Mathf.Sign(aimRaw.y));

        Vector2 currentInput = GetInput();
        
        if (lockHorizontalMove) currentInput.x = 0f;
        if (lockVerticalMove)   currentInput.y = 0f;
        
        if (stop)
		{
			rb.linearVelocity = new Vector2(0,0);
		}		
		else if (!isAttacking)
        {
            Vector2 p = rb.position;

            if (currentInput.x != 0f)
            {
                SnapAxisTo(p, true);
                SoftSnapMovingAxis(p, true);
                rb.position = p;
                
                rb.linearVelocity = new Vector2(currentInput.x * playerMoveSpeed, 0f);
                if (aim != Vector2.zero) HandleAnimation(aim);
            }
            else if (currentInput.y != 0f)
            {
                SnapAxisTo(p, false);
                SoftSnapMovingAxis(p, false);
                rb.position = p;
                
                rb.linearVelocity = new Vector2(0f, currentInput.y * playerMoveSpeed);
                if (aim != Vector2.zero) HandleAnimation(aim);
            }
            else
            {
                rb.linearVelocity = new Vector2(0, 0);
                p.x = RoundToMultiple(rb.position.x, halfStep);
                p.y = RoundToMultiple(rb.position.y, halfStep);
                rb.position = p;
                if (aim != Vector2.zero) HandleAnimation(aim);
            }
        }
        walking = rb.linearVelocity.sqrMagnitude > 0.0001f;
    }

    public Vector2 GetInput()
    {
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        if (Mathf.Abs(horizontalInput) > 0.0f)
        {
            verticalInput = 0.0f;
        }
        return new Vector2(horizontalInput, verticalInput);
    }

    void HandleAnimation(Vector2 move)
    {
        Sprite[] set = null;

        if (move.x > 0)
        {
            set = rightFrames;
            //sr.flipX = false;
            lastMoveDirection = Vector2.right;
            facingDir = "right";
            walking = true;
        }
        else if (move.x < 0)
        {
            set = leftFrames;
            //sr.flipX = true;
            lastMoveDirection = Vector2.left;
            facingDir = "left";
            walking = true;
        }
        else if (move.y > 0)
        {
            set = upFrames;
            //sr.flipX = false;
            lastMoveDirection = Vector2.up;
            facingDir = "up";
            walking = true;
        }
        else if (move.y < 0)
        {
            set = downFrames;
            //sr.flipX = false;
            lastMoveDirection = Vector2.down;
            facingDir = "down";
            walking = true;
        }
        else
        {
            return;
        }

        frameTimer += Time.deltaTime;
        if (frameTimer >= frameTime)
        {
            frameTimer = 0.0f;
            frameIndex = 1 - frameIndex;
        }

        sr.sprite = set[frameIndex];
    }
    
    void SnapAxisTo(Vector2 p, bool horizontalMove)
    {
        if (horizontalMove)
            p.y = RoundToMultiple(p.y, tileSize);
        else
            p.x = RoundToMultiple(p.x, tileSize);
    }
    
    void SoftSnapMovingAxis(Vector2 p, bool horizontalMove)
    {
        if (horizontalMove)
        {
            float target = RoundToMultiple(p.x, halfStep);
            if (Mathf.Abs(p.x - target) < snapEps) p.x = target;
        }
        else
        {
            float target = RoundToMultiple(p.y, halfStep);
            if (Mathf.Abs(p.y - target) < snapEps) p.y = target;
        }
    }

    public Vector3 GetFacingDirection()
    {
        switch (facingDir)
        {
            case "up": return Vector3.up;
            case "down": return Vector3.down;
            case "left": return Vector3.left;
            case "right": return Vector3.right;
        }
        return Vector3.zero;
    }
    void BowRoomLogicHandle()
    {
        if (inBowRoom)
        {
            if (touchingFloor && touchingLadder)
            {
                lockHorizontalMove = false;
                lockVerticalMove = false;
            }
            else if (touchingLadder)
            {
                lockVerticalMove = false;
                lockHorizontalMove = true;
            }
            else if (touchingFloor)
            {
                lockVerticalMove = true;
                lockHorizontalMove = false;
            }
            else
            {
                lockVerticalMove = true;
                lockHorizontalMove = false;
            }
        }
        else
        {
            lockHorizontalMove = false;
            lockVerticalMove = false;
        }
    }
}