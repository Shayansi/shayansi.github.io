using UnityEngine;

public class DropAssignment : MonoBehaviour
{
    public GameObject[] items; // Assign your 4 prefabs here in the inspector

    private void Awake()
    {
        Enemy.dropItems = items;
    }
}
