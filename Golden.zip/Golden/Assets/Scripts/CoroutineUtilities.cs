using UnityEngine;
using System.Collections;

public class CoroutineUtilities
{
    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPos, Vector3 finalPos, float duration)
    {
        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while (progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPos = Vector3.Lerp(initialPos, finalPos, progress);
            
            target.position = newPos;
            yield return null;
        }
        
        target.position =  finalPos;
    }
}
