using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    [Header("Health Settings")]
    public int maxHealth = 6;
    public int currentHealth;
    public Inventory inventory;

    public float Iduration = 1f; // invincibility duration
    private bool isInvincible = false;

    private Rigidbody rb;
    private SpriteRenderer spriteRenderer;
    private ArrowKeyMovement movement;

    public float knockbackTileDistance = 1f;
    public float knockbackSpeed = 6f;
    public float stunDuration = 0.5f;

    private bool isStunned = false;

    private AudioSource audioSource;
    public AudioClip damageSound;

    [Header("Clone Ability Settings")]
    public GameObject clonePrefab;          // Assign in Inspector
    public GameObject projectilePrefab;     // Assign in Inspector
    public float projectileSpeed = 8f;
    public float projectileDistance = 3f;

    private GameObject activeClone;         // Tracks if a clone is active

    void Start()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        inventory = GetComponent<Inventory>();
        movement = GetComponent<ArrowKeyMovement>();
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        // Press C to launch the clone ability
        if (Input.GetKeyDown(KeyCode.C))
        {
            Debug.Log("launching clone projectile");
            TryLaunchCloneProjectile();
        }
    }

    #region Clone Projectile Logic
    private void TryLaunchCloneProjectile()
    {
        // Don't launch if a clone already exists
        if (!inventory.hasClone) return;

        if (activeClone != null)
        {
            Debug.Log("Clone already active! Cannot launch another.");
            return;
        }

        // Determine direction based on player's facing direction
        Vector3 direction = movement.GetFacingDirection().normalized;

        // Create projectile at player's position
        GameObject projectile = Instantiate(projectilePrefab, transform.position, Quaternion.identity);

        // Attach the projectile behavior script dynamically
        CloneProjectile projScript = projectile.AddComponent<CloneProjectile>();
        projScript.Initialize(direction, projectileSpeed, projectileDistance, this);
    }

    // Called by CloneProjectile when the projectile completes travel
    public void SpawnCloneAt(Vector3 position)
    {
        if (activeClone != null) return;

        float checkRadius = 0.4f;
        Collider[] hitColliders = Physics.OverlapSphere(position, checkRadius);

        foreach (Collider col in hitColliders)
        {
            if (!col.CompareTag("projectile"))
            {
                Debug.Log("Cannot spawn clone, space is blocked by: " + col.name);
                return;
            }
        }

        activeClone = Instantiate(clonePrefab, position, Quaternion.identity);
        Debug.Log("Clone spawned at: " + position);

        Clone cloneScript = activeClone.GetComponent<Clone>();
        if (cloneScript != null)
        {
            cloneScript.onCloneDestroyed = () => { activeClone = null; };
        }
    }

    #endregion

    #region Damage and Knockback
    public void TakeDamage(int amount, Vector3 hitSource)
    {
        if (inventory.godMode || isInvincible) return;

        if (damageSound != null)
            audioSource.PlayOneShot(damageSound);

        currentHealth -= amount;
        if (currentHealth <= 0)
        {
            Die();
            return;
        }

        Vector3 knockbackDir = (transform.position - hitSource).normalized;

        StartCoroutine(SmoothKnockbackCoroutine(knockbackDir));
        StartCoroutine(InvincibilityCoroutine());
        StartCoroutine(StunCoroutine());
    }

    public void Heal(int amount)
    {
        currentHealth = Mathf.Min(currentHealth + amount, maxHealth);
    }

    public void Die()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private System.Collections.IEnumerator InvincibilityCoroutine()
    {
        isInvincible = true;
        float elapsed = 0f;

        while (elapsed < Iduration)
        {
            spriteRenderer.enabled = !spriteRenderer.enabled;
            yield return new WaitForSeconds(0.1f);
            elapsed += 0.1f;
        }

        spriteRenderer.enabled = true;
        isInvincible = false;
    }

    private System.Collections.IEnumerator StunCoroutine()
    {
        isStunned = true;

        if (movement != null)
            movement.enabled = false;

        yield return new WaitForSeconds(stunDuration);

        if (movement != null)
            movement.enabled = true;

        isStunned = false;
    }

    private System.Collections.IEnumerator SmoothKnockbackCoroutine(Vector3 direction)
    {
        if (movement != null)
            movement.enabled = false;

        Vector3 start = transform.position;
        Vector3 target = start + direction * knockbackTileDistance;

        float elapsed = 0f;
        float duration = knockbackTileDistance / knockbackSpeed;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            transform.position = Vector3.Lerp(start, target, t);
            yield return null;
        }

        transform.position = target;

        if (movement != null)
            movement.enabled = true;
    }
    #endregion
}
