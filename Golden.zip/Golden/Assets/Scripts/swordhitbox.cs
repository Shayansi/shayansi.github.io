using UnityEngine;

public class swordhitbox : MonoBehaviour
{
    private void OnTriggerEnter(Collider collision)
    {
        Debug.Log("Sword physical hit: " + collision.gameObject.name + " | Tag: " + collision.tag);
        if (collision.CompareTag("Enemy"))
        {
            Debug.Log("Damaging Enemy");
            Enemy enemy = collision.GetComponent<Enemy>();
            if (enemy != null) 
            {
                enemy.TakeDamage(1);
            }
        }
    }

    public void GodModeCallOn()
    {
        Physics2D.IgnoreLayerCollision(LayerMask.NameToLayer("Player"), LayerMask.NameToLayer("Enemies"), true);
    }
    
    public void GodModeCallOff()
    {
        Physics2D.IgnoreLayerCollision(LayerMask.NameToLayer("Player"), LayerMask.NameToLayer("Enemies"), false);
    }
}