using UnityEngine;

public class Collector : MonoBehaviour
{
    Inventory inventory;
    public AudioClip rupeeCollectionSound;
    public AudioClip bombCollectionSound;
    public AudioClip keyCollectionSound;
    public AudioClip heartCollectionSound;
    public PlayerHealth playerHealth;

    void Awake()
    {
        if (inventory == null)
        {
            var player = GameObject.FindWithTag("player");
            if (player != null && player.TryGetComponent(out Inventory inv))
            {
                inventory = inv;
            }
            else
            {
                Debug.LogWarning("Collector: couldn't find Player Inventory in scene");   
            }
        }

        if (playerHealth == null)
        {
            var player = GameObject.FindWithTag("player");

            if (player != null && player.TryGetComponent(out PlayerHealth hp))
            {
                playerHealth = hp;
            }
        }
    }
    void OnTriggerEnter(Collider other)
    {
        GameObject objectCollidedWith = other.gameObject;

        if (objectCollidedWith.tag == "rupee")
        {
            if (inventory != null)
            {
                inventory.AddRupees(1);
            }
            Destroy(objectCollidedWith);
            AudioSource.PlayClipAtPoint(rupeeCollectionSound, Camera.main.transform.position);
        }
        
        if (objectCollidedWith.tag == "droppedBomb")
        {
            if (inventory != null)
            {
                inventory.AddBombs(1);
            }
            Destroy(objectCollidedWith);
            AudioSource.PlayClipAtPoint(bombCollectionSound, Camera.main.transform.position);
        }
        
        if (objectCollidedWith.tag == "key")
        {
            if (inventory != null)
            {
                inventory.AddKeys(1);
            }
            Destroy(objectCollidedWith);
            AudioSource.PlayClipAtPoint(keyCollectionSound, Camera.main.transform.position);
        }
        
        if (objectCollidedWith.tag == "heart")
        {
            if (inventory != null)
            {
                playerHealth.Heal(1);
            }
            Destroy(objectCollidedWith);
            AudioSource.PlayClipAtPoint(heartCollectionSound, Camera.main.transform.position);
        }
    }
}
