using UnityEngine;

public class Bow : MonoBehaviour
{
    public GameObject arrowPrefab;
    public Transform firePoint;
    public float shootCooldown = 0.5f;

    [HideInInspector] public bool boomerangActive = false; // tracked by WeaponManager
    [HideInInspector] public ArrowKeyMovement movement;
    [HideInInspector] public Inventory inventory;

    private float lastShootTime = 0f;

    void Start()
    {
        movement = GetComponent<ArrowKeyMovement>();
        inventory = GetComponent<Inventory>();
    }

    public void ShootBow()
    {
        if (Time.time < lastShootTime + shootCooldown)
            return;

        if (inventory.GetRupees() <= 0)
        {
            Debug.Log("Not enough rupees to shoot");
            return;
        }

        inventory.AddRupees(-1);
        ShootArrow();
        lastShootTime = Time.time;
    }

    private void ShootArrow()
    {
        Vector2 shootDir = GetFacingDirection();
        Vector3 spawnPos = transform.position + (Vector3)shootDir * 0.5f;

        GameObject arrow = Instantiate(arrowPrefab, spawnPos, Quaternion.identity);
        arrow.GetComponent<Arrow>().SetDirection(shootDir);

        Debug.Log("Arrow fired, Remaining rupees: " + inventory.GetRupees());
    }

    private Vector2 GetFacingDirection()
    {
        switch (movement.facingDir)
        {
            case "up": return Vector2.up;
            case "down": return Vector2.down;
            case "left": return Vector2.left;
            case "right": return Vector2.right;
        }
        return Vector2.zero;
    }
}
