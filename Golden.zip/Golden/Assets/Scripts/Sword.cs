using UnityEngine;
using UnityEngine.Audio;

public class Sword : MonoBehaviour
{
    public float swingDuration = 0.2f;
    public Sprite swingUp;
    public Sprite swingDown;
    public Sprite swingLeft;
    public Sprite swingRight;
    public GameObject swordHitbox;
    public GameObject swordBeamPrefab;
    public PlayerHealth playerHealth;

    public float swordDistance = 0f;

    public AudioClip swordSwingSound;
    private AudioSource audioSource;

    public AudioClip swordBeamSound;

    private SpriteRenderer sr;
    private ArrowKeyMovement movement;

    // Track current active sword beam
    private GameObject currentSwordBeam;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        movement = GetComponent<ArrowKeyMovement>();
        playerHealth = GetComponent<PlayerHealth>();
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X) && !movement.isAttacking)
        {
            StartCoroutine(SwingSword());
        }
    }

    private System.Collections.IEnumerator SwingSword()
    {
        if (swordSwingSound != null)
        {
            audioSource.PlayOneShot(swordSwingSound);
        }

        movement.isAttacking = true;
        string dir = movement.facingDir;
        movement.rb.linearVelocity = Vector2.zero;

        Vector3 lungeDir = Vector3.zero;
        switch (dir)
        {
            case "up": lungeDir = Vector3.up; break;
            case "down": lungeDir = Vector3.down; break;
            case "left": lungeDir = Vector3.left; break;
            case "right": lungeDir = Vector3.right; break;
        }

        float lungeAmount = 0.5f;
        transform.position += lungeDir * lungeAmount;

        switch (dir)
        {
            case "up": sr.sprite = swingUp; break;
            case "down": sr.sprite = swingDown; break;
            case "left": sr.sprite = swingLeft; break;
            case "right": sr.sprite = swingRight; break;
        }

        UpdateSwordHitbox(dir);
        swordHitbox.SetActive(true);

        // Shoot sword beam only if full health AND no beam currently exists
        if (playerHealth.currentHealth == playerHealth.maxHealth && currentSwordBeam == null)
        {
            ShootSwordBeam(dir);
        }

        yield return new WaitForSeconds(swingDuration);

        swordHitbox.SetActive(false);

        transform.position -= lungeDir * lungeAmount;

        switch (dir)
        {
            case "up": sr.sprite = movement.upFrames[0]; break;
            case "down": sr.sprite = movement.downFrames[0]; break;
            case "left": sr.sprite = movement.leftFrames[0]; break;
            case "right": sr.sprite = movement.rightFrames[0]; break;
        }

        movement.isAttacking = false;
    }

    private void UpdateSwordHitbox(string dir)
    {
        switch (dir)
        {
            case "up":
                swordHitbox.transform.localPosition = new Vector3(0, swordDistance, 0);
                swordHitbox.transform.localRotation = Quaternion.identity;
                break;
            case "down":
                swordHitbox.transform.localPosition = new Vector3(0, -swordDistance, 0);
                swordHitbox.transform.localRotation = Quaternion.Euler(0, 0, 180);
                break;
            case "left":
                swordHitbox.transform.localPosition = new Vector3(-swordDistance, 0, 0);
                swordHitbox.transform.localRotation = Quaternion.Euler(0, 0, 90);
                break;
            case "right":
                swordHitbox.transform.localPosition = new Vector3(swordDistance, 0, 0);
                swordHitbox.transform.localRotation = Quaternion.Euler(0, 0, -90);
                break;
        }
    }

    private void ShootSwordBeam(string direction)
    {
        Vector2 shootDir = Vector2.zero;
        float rotationZ = 0f;

        if (swordBeamSound != null)
        {
            audioSource.PlayOneShot(swordBeamSound);
        }

        switch (direction)
        {
            case "up":
                shootDir = Vector2.up;
                rotationZ = 0f;
                break;
            case "down":
                shootDir = Vector2.down;
                rotationZ = 180f;
                break;
            case "left":
                shootDir = Vector2.left;
                rotationZ = 90f;
                break;
            case "right":
                shootDir = Vector2.right;
                rotationZ = -90f;
                break;
        }

        // Instantiate and track the beam
        currentSwordBeam = Instantiate(swordBeamPrefab, transform.position, Quaternion.Euler(0, 0, rotationZ));

        // Pass reference to the beam so it can notify when destroyed
        swordbeam beamScript = currentSwordBeam.GetComponent<swordbeam>();
        beamScript.direction = shootDir;
        beamScript.onBeamDestroyed = () => currentSwordBeam = null;
    }
}
