using UnityEngine;

public class Wallmaster : Enemy
{
    [Header("Wallmaster Settings")]
    public float tileSize = 1f;
    public float moveSpeed = 3f;
    public LayerMask triggerLayer;
    public float raycastDistance = 5f;
    public Vector3 raycastDirection = Vector3.right;

    private bool hasActivated = false;
    private Vector3 initialPosition;

    protected override void Start()
    {
        base.Start();
        rb = GetComponent<Rigidbody>();

        if (spriteRenderer == null)
            spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        spriteRenderer.enabled = false;

        initialPosition = transform.position;
    }

    private void Update()
    {
        if (hasActivated) return;

        if (Physics.Raycast(transform.position, raycastDirection, out RaycastHit hit, raycastDistance, triggerLayer))
        {
            Activate();
        }
    }

    private void Activate()
    {
        if (hasActivated) return;
        hasActivated = true;
        spriteRenderer.enabled = true;
        StartCoroutine(FollowPath());
    }

    private System.Collections.IEnumerator FollowPath()
    {
        Vector3 currentDir = raycastDirection.normalized;

        // Step 1: move 1 tile in the initial direction
        yield return StartCoroutine(MoveOneTile(currentDir, true));

        // Step 2: rotate 90� counterclockwise and move 3 tiles
        currentDir = Rotate90CounterClockwise(currentDir);
        for (int i = 0; i < 3; i++)
        {
            yield return StartCoroutine(MoveOneTile(currentDir, false));
        }

        // Step 3: rotate 90� counterclockwise again and move 1 tile
        currentDir = Rotate90CounterClockwise(currentDir);
        yield return StartCoroutine(MoveOneTile(currentDir, true));

        // Reset
        spriteRenderer.enabled = false;
        transform.position = initialPosition;
        hasActivated = false;
    }

    private Vector3 Rotate90CounterClockwise(Vector3 dir)
    {
        // Only works for cardinal directions
        if (dir == Vector3.up) return Vector3.left;
        if (dir == Vector3.left) return Vector3.down;
        if (dir == Vector3.down) return Vector3.right;
        if (dir == Vector3.right) return Vector3.up;
        return dir; // fallback
    }

    private System.Collections.IEnumerator MoveOneTile(Vector3 direction, bool pauseAfter)
    {
        Vector3 targetPosition = transform.position + direction * tileSize;

        while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
        {
            Vector3 newPos = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
            rb.MovePosition(newPos);
            yield return null;
        }

        transform.position = targetPosition;

        if (pauseAfter)
            yield return new WaitForSeconds(0.1f);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("player"))
        {
            ArrowKeyMovement player = other.gameObject.GetComponent<ArrowKeyMovement>();
            if (player != null)
            {
                Debug.Log("Caught Player");
                player.transform.position = new Vector3(40f, 3f, 0f);
                Camera.main.transform.position = new Vector3(39.5f, 7f, -10f);
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + raycastDirection.normalized * raycastDistance);
    }
}
