using UnityEngine;

public class switchTile : MonoBehaviour
{
    // Reference to the parent object script that has the boolean
    public switchManager sm;

    // Name of the boolean in the parent
    public int switchNum = 0;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("player"))
        {
            // Set the parent's boolean to true
            sm.flipSwitch(switchNum, true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("player"))
        {
            // Set the parent's boolean back to false
            sm.flipSwitch(switchNum, false);
        }
    }
}
