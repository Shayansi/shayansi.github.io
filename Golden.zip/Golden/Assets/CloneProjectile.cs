using UnityEngine;

public class CloneProjectile : MonoBehaviour
{
    private Vector3 direction;
    private float speed;
    private float maxDistance;
    private PlayerHealth player;
    private Vector3 startPos;

    private bool hitSomething = false;

    public void Initialize(Vector3 dir, float spd, float distance, PlayerHealth playerRef)
    {
        direction = dir;
        speed = spd;
        maxDistance = distance;
        player = playerRef;
        startPos = transform.position;
    }

    void Update()
    {
        if (hitSomething) return; // Stop moving after collision

        // Move forward
        transform.position += direction * speed * Time.deltaTime;

        // Check if max distance is reached
        if (Vector3.Distance(startPos, transform.position) >= maxDistance)
        {
            player.SpawnCloneAt(transform.position);
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // Ignore collisions with the player or other projectiles
        if (other.CompareTag("player") || other.CompareTag("Water")) return;

        hitSomething = true;
        Debug.Log("Projectile hit: " + other.name);

        // Destroy projectile immediately and do NOT spawn a clone
        Destroy(gameObject);
    }
}
