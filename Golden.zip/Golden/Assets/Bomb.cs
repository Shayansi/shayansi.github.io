using UnityEngine;
using System.Collections;

public class Bomb : MonoBehaviour
{
    [SerializeField] private GameObject explosionPrefab;
    [SerializeField] private float fuseSeconds = 1f;
    [SerializeField] private float explosionSeconds = 1f;
    [SerializeField] private float damageRadius = 1f;
    [SerializeField] private int damage = 1;
    [SerializeField] private LayerMask enemyMask = ~0;
    public AudioClip bombSound;
    [SerializeField] private AudioSource sfxBus;
    
    private Vector2 direction;
    
    void Awake()
    {
        if (!sfxBus)
        {
            var player = GameObject.FindGameObjectWithTag("Player");
            if (player) sfxBus = player.GetComponent<AudioSource>();
        }
    }
    
    void Start()
    {
        StartCoroutine(Fuse());
    }
    IEnumerator Fuse()
    {
        yield return new WaitForSeconds(fuseSeconds);
        
        if (sfxBus)
        {
            sfxBus.PlayOneShot(bombSound);
        }
        else
        {
            var at = Camera.main ? Camera.main.transform.position : transform.position;
            var go = new GameObject("BombSFX_2D");
            var src = go.AddComponent<AudioSource>();
            src.spatialBlend = 0f;
            src.clip = bombSound;
            src.Play();
            Destroy(go, bombSound.length);
        }
        
        Explode();
    }
    
    public void Explode()
    {
        GameObject fx = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        Destroy(fx, explosionSeconds);
        
        Collider[] hits = Physics.OverlapSphere(transform.position, damageRadius, enemyMask, QueryTriggerInteraction.Collide);
        for (int i = 0; i < hits.Length; i++)
        {
            if (!hits[i].CompareTag("Enemy"))
            {
                continue;
            }
            var enemy = hits[i].GetComponent<Enemy>();

            if (enemy != null)
            {
                enemy.TakeDamage(damage);
            }
        }
        Destroy(gameObject);
    }
    
    public void SetDirection(Vector2 dir)
    {
        direction = dir.normalized;
    }
}
