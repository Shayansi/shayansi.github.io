using UnityEngine;

public class fireball : MonoBehaviour
{
    public int damage = 1;
    public float lifetime = 5f;

    private void Start()
    {
        // Optional auto-destroy after some time
        // Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("player"))
        {
            PlayerHealth player = other.GetComponent<PlayerHealth>();
            if (player != null)
            {
                player.TakeDamage(damage, transform.position);
            }

            Destroy(gameObject);
        }
        else if (other.CompareTag("Wall"))
        {
            Destroy(gameObject);
        }
    }
}
