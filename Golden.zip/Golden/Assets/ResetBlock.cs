using UnityEngine;

public class ResetBlock : MonoBehaviour
{
    [SerializeField] private GameObject block;
    [SerializeField] private GameObject blockReset;
    [SerializeField] private Moveable moveableScript;
    [SerializeField] private RoomLockOnEntry roomLockOnEntry;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void BlockMove()
    {
        block.transform.position = blockReset.transform.position;
        moveableScript.sliding = false;
        moveableScript.moved = false;
		roomLockOnEntry.canOpen = false;
    }
}
