using UnityEngine;

public class BlockScreenWipe : MonoBehaviour
{
    [SerializeField] private RectTransform blackPanel;
    [SerializeField] private float expandTime = 0.25f;
    [SerializeField] private float holdTime = 1f;
    [SerializeField] private float shrinkTime = 0.25f;
    [SerializeField] private Transform player;
    [SerializeField] private GameObject moveableBlock;
    [SerializeField] private Transform cameraToMove;
    [SerializeField] private Transform playerDestination;
    [SerializeField] private Vector3 cameraDestination;
    [SerializeField] private Transform moveableBlockStart;
    [SerializeField] private ArrowKeyMovement arrowKeyMovement;
    [SerializeField] Moveable moveableScript;

    bool running = false;
    int phase = 0;
    float t = 0f;

    void Start()
    {
        if (blackPanel != null)
        {
            blackPanel.localScale = Vector3.zero;
            blackPanel.gameObject.SetActive(false);
        }
    }

    void Update()
    {
        if (!running || blackPanel == null) return;

        if (phase == 0)
        {
            t += Time.deltaTime / Mathf.Max(0.0001f, expandTime);
            blackPanel.localScale = Vector3.LerpUnclamped(Vector3.zero, Vector3.one, Mathf.Clamp01(t));
            if (t >= 1f) { phase = 1; t = 0f; }
        }
        else if (phase == 1)
        {
            t += Time.deltaTime;
            if (t >= holdTime)
            {
                player.position = playerDestination.position;
                cameraToMove.position = cameraDestination;
				if (moveableBlock)
				{
					moveableBlock.transform.position = moveableBlockStart.position;
                	moveableScript.sliding = false;
					moveableScript.moved = false;
				}  
                phase = 2;
                t = 0f;
            }
        }
        else if (phase == 2)
        {
            t += Time.deltaTime / Mathf.Max(0.0001f, shrinkTime);
            blackPanel.localScale = Vector3.LerpUnclamped(Vector3.one, Vector3.zero, Mathf.Clamp01(t));
            if (t >= 1f)
            {
                blackPanel.localScale = Vector3.zero;
                blackPanel.gameObject.SetActive(false);
                running = false;
                phase = 0;
                t = 0f;
            }
        }
    }

    void OnCollisionEnter(Collision c)
    {
        
        if (running) return;
        if (c.gameObject.CompareTag("player"))
        {
            blackPanel.gameObject.SetActive(true);
            blackPanel.localScale = Vector3.zero;
            running = true;
            phase = 0;
            t = 0f;
            arrowKeyMovement.inBowRoom = !arrowKeyMovement.inBowRoom;
        }
    }
}