using UnityEngine;

public class RemoveText : MonoBehaviour
{
    [SerializeField] private GameObject text;
    [SerializeField] private OldManScript oldManScript;

    void OnTriggerEnter()
    {
        oldManScript.RemoveText();
    }
}
